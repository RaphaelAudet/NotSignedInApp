define("widgets/widgets", [

], function() {});